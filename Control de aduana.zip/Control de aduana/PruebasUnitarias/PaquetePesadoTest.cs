﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca;

namespace PruebasUnitarias
{
    [TestClass]
    public class PaquetePesadoTest
    {
        [TestMethod]
        public void AplicarImpuestos_DeberiaRetornarCostoDeEnvioMasImpuestosAfipYAduana()
        {
            PaquetePesado paquete = new PaquetePesado("codigo", 100, "destino", "origen", 100);
            decimal actual;
            decimal expected = 160;

            actual = paquete.AplicarImpuestos();

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Impuestos_DeberiaRetornarValorImpuestosDel25PorCientoSobreCostoEnvio_CuandoEsImplementacionExplicitaAfip()
        {
            PaquetePesado paquete = new PaquetePesado("codigo", 100, "destino", "origen", 100);
            decimal actual;
            decimal expected = 25;

            actual = ((IAfip)paquete).Impuestos;

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Impuestos_DeberiaRetornarValorImpuestosDel35PorCientoSobreCostoEnvio_CuandoEsImplementacionImplicita()
        {
            PaquetePesado paquete = new PaquetePesado("codigo", 100, "destino", "origen", 100);
            decimal actual;
            decimal expected = 35;

            actual = paquete.Impuestos;

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TienePrioridad_DeberiaRetornarFalse()
        {
            PaquetePesado paquete = new PaquetePesado("codigo", 100, "destino", "origen", 100);

            Assert.IsFalse(paquete.TienePrioridad);
        }
    }
}
