using Microsoft.VisualStudio.TestTools.UnitTesting;
using Biblioteca;

namespace PruebasUnitarias
{
    [TestClass]
    public class PaqueteFragilTest
    {
        [TestMethod]
        public void AplicarImpuestos_DeberiaRetornarCostoDeEnvioMasImpuestosAduana()
        {
            PaqueteFragil paquete = new PaqueteFragil("codigo", 100, "destino", "origen", 100);
            decimal actual;
            decimal expected = 135;

            actual = paquete.AplicarImpuestos();

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Impuestos_DeberiaRetornarValorImpuestoDel35PorCientoSobreCostoEnvio()
        {
            PaqueteFragil paquete = new PaqueteFragil("codigo", 100, "destino", "origen", 100);
            decimal actual;
            decimal expected = 35;

            actual = paquete.Impuestos;

            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TienePrioridad_DeberiaRetornarTrue()
        {
            PaqueteFragil paquete = new PaqueteFragil("codigo", 100, "destino", "origen", 100);
            
            Assert.IsTrue(paquete.TienePrioridad);
        }
    }
}
