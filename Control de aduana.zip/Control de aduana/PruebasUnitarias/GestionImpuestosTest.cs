﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca;

namespace PruebasUnitarias
{
    [TestClass]
    public class GestionImpuestosTest
    {
        [TestMethod]
        public void CalcularTotalImpuestosAduana_DeberiaRetornarLaSumaDeLosImpuestosDeAduana()
        {
            GestionImpuestos gestion = new GestionImpuestos();
            PaquetePesado paqueteP = new PaquetePesado("codigo", 100, "destino", "origen", 100);
            PaqueteFragil paqueteF = new PaqueteFragil("codigo", 100, "destino", "origen", 100);
            gestion.RegistrarImpuestos(paqueteP);
            gestion.RegistrarImpuestos(paqueteF);
            decimal actual;
            decimal expected = 70;

            actual = gestion.CalcularTotalImpuestosAduana();

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void CalcularTotalImpuestosAfip_DeberiaRetornarLaSumaDeLosImpuestosDeAfip()
        {
            GestionImpuestos gestion = new GestionImpuestos();
            PaquetePesado paqueteP = new PaquetePesado("codigo", 100, "destino", "origen", 100);
            PaqueteFragil paqueteF = new PaqueteFragil("codigo", 100, "destino", "origen", 100);
            gestion.RegistrarImpuestos(paqueteP);
            gestion.RegistrarImpuestos(paqueteF);
            decimal actual;
            decimal expected = 25;

            actual = gestion.CalcularTotalImpuestosAfip();

            Assert.AreEqual(expected, actual);
        }
    }
}
