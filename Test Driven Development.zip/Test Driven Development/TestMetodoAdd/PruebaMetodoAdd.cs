using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestMetodoAdd
{
    [TestClass]
    public class PruebaMetodoAdd
    {
        [TestMethod]
        public void Add_CuandoRecibeHasta2String_DeberiaDevolverLasuma()
        {
            string texto = "1,2";
            int expected = 3;
            int actual;

            actual = ClaseMetodo.Add(texto);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Add_CuandoRecibeVariosString_DeberiaSumarlosTodos()
        {
            string texto = "1,2,44,3";
            int expected = 50;
            int actual;

            actual= ClaseMetodo.Add(texto);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Add_CuandoRecibeStringConSaltoDeLinea_DeberiaSumarLosString()
        {
            string texto = "1 \n2,3";
            int expected = 6;
            int actual;

            actual = ClaseMetodo.Add(texto);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Add_CuandoRecibeUnDelimitador_DeberiaSumarLosStringSeparandoPorSimboloLimitador()
        {
            string texto = "//; \n1; 2";
            int expected = 3;
            int actual;

            actual = ClaseMetodo.Add(texto);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        [ExpectedException(typeof(NegativoNoPermitidoException))]
        public void Add_CuandoRecibeUnNumeroNegativo_DeberiaSumarLosStringSeparandoPorSimboloLimitadorLanzarNegativoNoPermitidoException()
        {
            string texto = "//; \n1; -2";

            int actual = ClaseMetodo.Add(texto);

        }
    }
}
