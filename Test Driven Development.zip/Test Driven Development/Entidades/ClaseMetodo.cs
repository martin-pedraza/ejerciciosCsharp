﻿using System;

namespace Entidades
{
    public class ClaseMetodo
    {
        public static int Add(string numero)
        {
            int sumador = 0;
            String[] numeros = new String[100];
            char c = ' ';
            if (numero[0] == '/' && numero[1] == '/')
            {
                c = numero[2];
            }
            numeros = numero.Split(new char[] { ',', '\n', c });
            foreach (string item in numeros)
            {
                if (!String.IsNullOrWhiteSpace(item) && item != "//")
                {
                    if (int.Parse(item) > 0)
                    {
                        sumador += int.Parse(item);
                    }
                    else
                    {
                        throw new NegativoNoPermitidoException(item);
                    }
                }
            }
            return sumador;
        }
    }
}
