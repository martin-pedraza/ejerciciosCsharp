using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestLaCentralita
{
    [TestClass]
    public class UnitTestCentralita
    {
        [TestMethod]
        public void ConstructorSinParametros_LlamarAlConstructor_DeberiaInstanciarLaLista()
        {
            Centralita c = new Centralita();
            
            Assert.IsNotNull(c.Llamadas);
        }
    }
}
