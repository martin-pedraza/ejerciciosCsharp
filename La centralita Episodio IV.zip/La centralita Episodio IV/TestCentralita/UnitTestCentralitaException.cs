﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestLaCentralita
{
    [TestClass]
    public class UnitTestCentralitaException
    {
        [TestMethod]
        [ExpectedException(typeof(CentralitaException))]
        public void GenerarUnaLlamadaLocal_CrearDosLlamadasIguales_DeberiaLanzarLaExcepcion()
        {
            Centralita c = new Centralita();
            c += new Local("aqui", 10, "alla", 2);
            c += new Local("aqui", 30, "alla", 4);
        }
        [TestMethod]
        [ExpectedException(typeof(CentralitaException))]
        public void GenerarUnaLlamadaProvincial_CrearDosLlamadasIguales_DeberiaLanzarLaExcepcion()
        {
            Centralita c = new Centralita();
            c += new Provincial("aqui", Franjas.Franja_2, 10, "alla");
            c += new Provincial("aqui", Franjas.Franja_1, 5, "alla");
        }
        [TestMethod]
        [ExpectedException(typeof(CentralitaException))]
        public void GenerarCuatroLlamadas_CrearDosLlamadasIgualesDeCadaUna_DeberiaLanzarLaExcepcion()
        {
            Centralita c = new Centralita();
            c += new Provincial("aqui", Franjas.Franja_2, 10, "alla");
            c += new Provincial("aqui", Franjas.Franja_1, 5, "alla");
            c += new Local("aqui", 10, "alla", 2);
            c += new Local("aqui", 30, "alla", 4);
        }
    }
}
