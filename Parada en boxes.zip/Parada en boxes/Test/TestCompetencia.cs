using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using System.Collections.Generic;

namespace Test
{
    [TestClass]
    public class TestCompetencia
    {
        [TestMethod]
        public void ConstructorSinParametros_CrearUnaNuevaCompetencia_DeberiiaInstanciarLaList()
        {
            List<VehiculoDeCarrera> actual;

            Competencia competencia = new Competencia(2, 2, Competencia.TipoCompetencia.F1);
            actual = competencia.Competidores;

            Assert.IsNotNull(actual);
        }
        [TestMethod]
        [ExpectedException(typeof(CompetenciaNoDisponibleException))]
        public void OperatorMas_CuandoSeAgregueUnAutoF1EnCompetenciaMotoCross_DeberiaLanzarExcepcionCompetenciaNoDisponible()
        {
            Competencia competencia = new Competencia(2, 2, Competencia.TipoCompetencia.MotoCross);
            AutoF1 autoF1 = new AutoF1(5, "Ford");

            if(competencia + autoF1) { }
        }
        [TestMethod]
        public void OperatorMas_CuandoSeAgregueUnMotoCrossEnCompetenciaMotoCross_NoDeberiaLanzarExcepcionCompetenciaNoDisponible()
        {
            Competencia competencia = new Competencia(2, 2, Competencia.TipoCompetencia.MotoCross);
            MotoCross motoCross = new MotoCross(5, "Ford");

            Assert.IsTrue(competencia + motoCross);
        }
        [TestMethod]
        public void OperatorIgual_CargarNuevoVehiculoYComprobarQueFigure_DeberiaRetornarTrue()
        {
            Competencia competencia = new Competencia(2, 2, Competencia.TipoCompetencia.MotoCross);
            MotoCross motoCross = new MotoCross(5, "Ford");

            if (competencia + motoCross) { }

            Assert.IsTrue(competencia == motoCross);
        }
        [TestMethod]
        public void OperatorDecigual_QuitarVehiculoYComprobarQueNoFigure_DeberiaRetornarTrue()
        {
            Competencia competencia = new Competencia(2, 2, Competencia.TipoCompetencia.MotoCross);
            MotoCross motoCross = new MotoCross(5, "Ford");

            if (competencia + motoCross) { }
            if (competencia - motoCross) { }

            Assert.IsTrue(competencia != motoCross);
        }
    }
}
